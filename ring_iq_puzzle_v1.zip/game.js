(() => {
  "use strict";
  const SIZE=4, COLORS={coral:"#f05d67",blue:"#438de5",green:"#46bf83",purple:"#9a68d7",orange:"#f59a36",yellow:"#e9bd32"};
  // Each level contains same-colour pairs. A pair clears when adjacent rings' gaps face one another.
  const LEVELS=[
    {pairs:[["coral",0,1],["blue",8,9]],goal:2,desc:"Connect two matching pairs. Tap a ring to rotate its opening."},
    {pairs:[["green",0,1],["purple",6,10],["orange",14,15]],goal:3,desc:"Three pairs are waiting. Move rings to line up their openings."},
    {pairs:[["blue",1,5],["coral",8,9],["yellow",10,11],["green",14,15]],goal:4,desc:"Four pairs! A ring can only connect to a neighbour of its own colour."},
    {pairs:[["purple",0,4],["orange",2,3],["blue",9,10],["green",12,13],["coral",14,15]],goal:5,desc:"A bigger board challenge: plan your rotations and moves."},
    {pairs:[["yellow",0,1],["coral",2,6],["blue",8,9],["purple",10,11],["green",12,13],["orange",14,15]],goal:6,desc:"Final test: clear every pair. Use hints if you get stuck."}
  ];
  const $=id=>document.getElementById(id);
  let level=0, rings=[], moves=0, iq=Number(localStorage.getItem("ringIQ")||100);
  let unlocked=Math.max(1,Number(localStorage.getItem("ringUnlocked")||1)), sound=true, drag=null, toastTimer, audioCtx=null;
  function tone(freq=520,duration=.09){
    if(!sound)return;
    try{
      audioCtx=audioCtx||new (window.AudioContext||window.webkitAudioContext)();
      if(audioCtx.state==="suspended")audioCtx.resume();
      const osc=audioCtx.createOscillator(),gain=audioCtx.createGain();
      osc.type="sine";osc.frequency.value=freq;gain.gain.setValueAtTime(.0001,audioCtx.currentTime);
      gain.gain.exponentialRampToValueAtTime(.08,audioCtx.currentTime+.012);
      gain.gain.exponentialRampToValueAtTime(.0001,audioCtx.currentTime+duration);
      osc.connect(gain);gain.connect(audioCtx.destination);osc.start();osc.stop(audioCtx.currentTime+duration);
    }catch(_){/* Audio is optional; gameplay remains available if Web Audio is blocked. */}
  }
  const board=$("board");
  const dirs=[{x:0,y:-1},{x:1,y:0},{x:0,y:1},{x:-1,y:0}]; // up, right, down, left
  const idx=(x,y)=>y*SIZE+x;
  function save(){localStorage.setItem("ringIQ",String(iq));localStorage.setItem("ringUnlocked",String(unlocked));}
  function notify(msg){const el=$("message");el.textContent=msg;el.classList.add("show");clearTimeout(toastTimer);toastTimer=setTimeout(()=>el.classList.remove("show"),1800);}
  function svgRing(color,dir){
    // Gap is a 54-degree opening centered on dir; end caps make the open ring readable.
    const start=-90+dir*90+27, end=start+306;
    const p=(a,r=42)=>({x:50+r*Math.cos(a*Math.PI/180),y:50+r*Math.sin(a*Math.PI/180)});
    const a=p(start),b=p(end);
    return `<svg viewBox="0 0 100 100" aria-hidden="true"><defs><linearGradient id="g-${color}" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#fff" stop-opacity=".8"/><stop offset=".25" stop-color="${COLORS[color]}"/><stop offset="1" stop-color="#333" stop-opacity=".18"/></linearGradient></defs><path d="M ${a.x} ${a.y} A 42 42 0 1 1 ${b.x} ${b.y}" fill="none" stroke="#ffffff" stroke-width="17" opacity=".72" transform="translate(0 2)"/><path d="M ${a.x} ${a.y} A 42 42 0 1 1 ${b.x} ${b.y}" fill="none" stroke="url(#g-${color})" stroke-width="13" stroke-linecap="round"/><circle cx="${a.x}" cy="${a.y}" r="6.2" fill="${COLORS[color]}" stroke="#fff" stroke-width="2"/><circle cx="${b.x}" cy="${b.y}" r="6.2" fill="${COLORS[color]}" stroke="#fff" stroke-width="2"/><circle cx="37" cy="27" r="5" fill="#fff" opacity=".35"/></svg>`;
  }
  function makeLevel(n){
    level=n;const data=LEVELS[n];rings=Array(SIZE*SIZE).fill(null);moves=0;
    data.pairs.forEach(([color,a,b],i)=>{
      // The deterministic starting angles are intentionally mixed; rotate to align.
      rings[a]={id:`${n}-${i}-a`,color,dir:(i+1)%4};
      rings[b]={id:`${n}-${i}-b`,color,dir:(i+3)%4};
    });
    $("levelLabel").textContent=`LEVEL ${n+1}`;
    $("levelGoal").textContent=data.desc;
    updateUI();render();
  }
  function updateUI(){
    const cleared=LEVELS[level].goal-rings.filter(Boolean).length/2;
    const pct=Math.max(0,Math.min(100,cleared/LEVELS[level].goal*100));
    $("progressLabel").textContent=`${cleared} / ${LEVELS[level].goal} LINKS`;
    $("progressFill").style.width=pct+"%";$("iqScore").textContent=iq;
  }
  function render(){
    board.innerHTML="";
    for(let i=0;i<SIZE*SIZE;i++){
      const slot=document.createElement("div");slot.className="slot";slot.dataset.index=i;
      const r=rings[i];
      if(r){
        const el=document.createElement("div");el.className="ring";el.dataset.id=r.id;el.dataset.index=i;el.innerHTML=svgRing(r.color,r.dir);
        el.setAttribute("role","button");el.setAttribute("aria-label",`${r.color} ring, opening ${["up","right","down","left"][r.dir]}`);
        slot.appendChild(el);
      }
      slot.addEventListener("pointerdown",onPointerDown);
      slot.addEventListener("pointerup",onPointerUp);
      slot.addEventListener("pointercancel",clearDrag);
      slot.addEventListener("pointermove",onPointerMove);
      board.appendChild(slot);
    }
  }
  function adjacent(a,b){const ax=a%SIZE,ay=Math.floor(a/SIZE),bx=b%SIZE,by=Math.floor(b/SIZE);return Math.abs(ax-bx)+Math.abs(ay-by)===1;}
  function direction(from,to){const dx=(to%SIZE)-(from%SIZE),dy=Math.floor(to/SIZE)-Math.floor(from/SIZE);return dx===1?1:dx===-1?3:dy===1?2:0;}
  function findMatches(){
    const found=[];
    for(let i=0;i<rings.length;i++)if(rings[i]){
      for(const d of [1,2]){
        const x=i%SIZE,y=Math.floor(i/SIZE),nx=x+dirs[d].x,ny=y+dirs[d].y;
        if(nx>=SIZE||ny>=SIZE)continue;
        const j=idx(nx,ny),a=rings[i],b=rings[j];
        if(b&&a.color===b.color&&a.dir===direction(i,j)&&b.dir===(direction(i,j)+2)%4)found.push([i,j]);
      }
    }
    return found;
  }
  function clearMatches(){
    const pairs=findMatches();if(!pairs.length)return false;tone(660,.12);
    const ids=new Set(pairs.flat());
    ids.forEach(i=>{const el=board.querySelector(`.slot[data-index="${i}"] .ring`);if(el)el.classList.add("clearing");});
    setTimeout(()=>{
      ids.forEach(i=>rings[i]=null);
      iq+=pairs.length*10;save();updateUI();render();
      if(rings.every(x=>!x))winLevel();
      else notify(`${pairs.length} pair${pairs.length>1?"s":""} connected and cleared!`);
    },350);
    return true;
  }
  function rotate(i){if(!rings[i])return;rings[i].dir=(rings[i].dir+1)%4;moves++;tone(440,.05);render();if(!clearMatches())notify("Opening rotated. Keep matching the gaps!");}
  function onPointerDown(e){
    const slot=e.currentTarget,i=Number(slot.dataset.index),ring=rings[i];
    if(!ring)return;
    e.preventDefault();drag={from:i,pointerId:e.pointerId,startX:e.clientX,startY:e.clientY,moved:false};
    slot.setPointerCapture?.(e.pointerId);
    const el=slot.querySelector(".ring");el.classList.add("selected");
  }
  function onPointerMove(e){
    if(!drag||drag.pointerId!==e.pointerId)return;
    if(Math.hypot(e.clientX-drag.startX,e.clientY-drag.startY)>12)drag.moved=true;
  }
  function onPointerUp(e){
    if(!drag||drag.pointerId!==e.pointerId)return;
    const from=drag.from,moved=drag.moved;clearDrag();
    if(!moved){rotate(from);return;}
    const target=document.elementFromPoint(e.clientX,e.clientY)?.closest(".slot");
    if(!target)return;
    const to=Number(target.dataset.index);
    if(to===from)return;
    if(!rings[to]&&adjacent(from,to)){
      rings[to]=rings[from];rings[from]=null;moves++;render();
      if(!clearMatches())notify("Moved! Rotate the ring to connect it.");
    }else if(!rings[to]){
      notify("Move rings one space at a time.");
    }else notify("That space is occupied.");
  }
  function clearDrag(){if(drag){const el=board.querySelector(`.ring[data-index="${drag.from}"]`);el?.classList.remove("selected");}drag=null;}
  function winLevel(){
    const reward=25+level*10;iq+=reward;unlocked=Math.max(unlocked,Math.min(LEVELS.length,level+2));save();updateUI();
    $("rewardIQ").textContent=reward;$("winText").textContent=`You cleared all ${LEVELS[level].goal} pairs in ${moves} moves.`;
    $("nextBtn").textContent=level===LEVELS.length-1?"PLAY AGAIN ↻":"NEXT LEVEL →";
    $("winModal").classList.remove("hidden");
  }
  function hint(){
    const pairs=findPotentialPairs();
    if(!pairs.length){notify("No matching neighbours yet. Try moving two same-colour rings together.");return;}
    const [a,b]=pairs[0],wantA=direction(a,b),wantB=(wantA+2)%4;
    const rA=rings[a],rB=rings[b];
    const turnsA=(wantA-rA.dir+4)%4,turnsB=(wantB-rB.dir+4)%4;
    if(turnsA===0&&turnsB===0){notify("This pair is ready to connect!");}
    else notify(`Hint: rotate the highlighted pair to face each other.`);
    [a,b].forEach(i=>{const el=board.querySelector(`.ring[data-index="${i}"]`);el?.classList.add("hinted");setTimeout(()=>el?.classList.remove("hinted"),2100);});
  }
  function findPotentialPairs(){
    const out=[];
    for(let i=0;i<rings.length;i++)if(rings[i])for(let j=0;j<rings.length;j++)if(rings[j]&&j>i&&rings[i].color===rings[j].color&&adjacent(i,j))out.push([i,j]);
    return out;
  }
  function boost(){
    const p=findPotentialPairs()[0];
    if(!p){notify("No adjacent matching pair. Move same-colour rings together first.");return;}
    const [a,b]=p,want=direction(a,b);rings[a].dir=want;rings[b].dir=(want+2)%4;render();notify("Booster aligned a matching pair!");
    setTimeout(()=>clearMatches(),120);
  }
  function showLevels(){
    const grid=$("levelGrid");grid.innerHTML="";
    LEVELS.forEach((_,i)=>{const b=document.createElement("button");b.textContent=i+1;b.disabled=i+1>unlocked;b.className=(i+1<=unlocked?"unlocked ":"")+(i===level?"current":"");b.addEventListener("click",()=>{$("levelModal").classList.add("hidden");$("winModal").classList.add("hidden");makeLevel(i);});grid.appendChild(b);});
    $("levelModal").classList.remove("hidden");
  }
  $("hintBtn").addEventListener("click",hint);$("boostBtn").addEventListener("click",boost);
  $("restartBtn").addEventListener("click",()=>{makeLevel(level);notify("Level restarted.");});
  $("levelsBtn").addEventListener("click",showLevels);$("closeLevels").addEventListener("click",()=>$("levelModal").classList.add("hidden"));
  $("soundBtn").addEventListener("click",()=>{sound=!sound;$("soundBtn").innerHTML=`${sound?"🔊":"🔇"} <span>SOUND ${sound?"ON":"OFF"}</span>`;if(sound)tone(740,.08);notify(sound?"Sound enabled.":"Sound muted.");});
  $("nextBtn").addEventListener("click",()=>{ $("winModal").classList.add("hidden");makeLevel((level+1)%LEVELS.length);});
  // Prevent browser page scrolling only while a ring is actively being dragged.
  document.addEventListener("touchmove",e=>{if(drag)e.preventDefault();},{passive:false});
  makeLevel(0);
})();