# Ring IQ — Connect & Clear

A mobile-first HTML5 puzzle game built with vanilla HTML, CSS and JavaScript. No frameworks, paid libraries, build step, or external assets are required.

## Play
- Each glossy ring has an opening shown by two small end caps.
- Tap a ring to rotate its opening clockwise (up → right → down → left).
- Drag a ring to an empty neighbouring cell to reposition it.
- Two adjacent rings of the same colour connect when both openings face each other. Connected pairs clear automatically.
- Clear every pair to finish the level.
- **Hint** highlights a possible same-colour neighbouring pair.
- **Boost** automatically aligns the first possible pair.
- **Restart** resets the current level. **Levels** opens the level selector.

## Features
- Five handcrafted levels with gradually increasing pair counts.
- IQ score, progress bar, completion rewards and unlock progression.
- Local progress saved with `localStorage`.
- Pointer Events for mouse, pen and touch input.
- Responsive 4×4 board and touch-friendly controls.
- Reduced accidental page scrolling during active board interaction.

## Run locally
Open `index.html` in a modern browser. For local development, a simple static server is recommended:

```bash
python -m http.server 8000
```

Then visit `http://localhost:8000`.

## Publish on GitHub Pages
1. Upload `index.html`, `style.css`, `game.js` and `README.md` to the repository root.
2. In **Settings → Pages**, select **Deploy from a branch**.
3. Select your main branch and `/ (root)`, then save.
4. Open the published Pages URL.

## Notes
The sound control is currently a functional mute-state UI toggle; this first prototype does not generate audio. The puzzle, movement, rotations, matching, clearing, hints, booster, levels, rewards and save system are implemented.
